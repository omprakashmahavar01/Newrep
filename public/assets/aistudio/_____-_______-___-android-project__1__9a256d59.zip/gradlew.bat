@rem Gradle startup script for Windows
@if "%DEBUG%" == "" @echo off
java -classpath "%~dp0gradle/wrapper/gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*